import RoomsComponent from './roomComponent'

export default RoomsComponent